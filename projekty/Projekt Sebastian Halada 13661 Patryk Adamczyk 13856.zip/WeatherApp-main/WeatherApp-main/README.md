# WeatherAppC-
Final project for school
Sebastian Halada 13661
Patryk Adamczyk 13856
